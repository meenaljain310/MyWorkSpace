package demo.beans;

public class Wallet {
	private float balance;
	

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	

}
